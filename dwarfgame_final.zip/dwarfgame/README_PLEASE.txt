DWARF GAME PROJECT - Created by Andrew Smith

SETUP
-----

Required Technology to be installed before running:

Tested on Ubuntu and Windows 10.

Please download and install.....

Python Version - 3.7.5 (Possibly may use higher version)
PyGame 1.9.4


GAME PLAY
---------

The aim of the game is to kill all enemy dwarfs to complete the game.  If they kill you first then you loose the game...simple.

The health game objects are set to boost energy by an additonal 25 points

The shield object can only be collected when the axe object is collected (it's been written that way).

Controls
--------

Cursor keys (Up, Down, Left, Right) are used to control direction of dwarf (Green)

Space Bar - Attack

Escape Key - End Game




